﻿namespace OT.Assessment.Tester.Infrastructure;

internal class Game
{
    public string Name { get; set; }
    public string Theme { get; set; }
}