﻿namespace OT.Assessment.Tester.Infrastructure;

internal class Provider
{
    public string Name { get; set; }
    public List<Game> Games { get; set; }
}