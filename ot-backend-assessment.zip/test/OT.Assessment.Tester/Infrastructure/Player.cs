﻿namespace OT.Assessment.Tester.Infrastructure;

internal class Player
{
    public Guid AccountId { get; set; }
    public string Username { get; set; }
}