// Global using directives

global using Bogus;
global using NBomber.CSharp;
global using NBomber.Http;
global using NBomber.Http.CSharp;
global using OT.Assessment.Tester.Infrastructure;
global using System.Text;
global using System.Text.Json;
